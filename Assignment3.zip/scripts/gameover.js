BreakoutGame.screens['gameover'] = (function(game) {
	'use strict';
	
	function initialize() {
		document.getElementById('gameover-scores-btn').addEventListener('click',function(){game.showScreen('scores');});

		document.getElementById('gameover-back').addEventListener(
			'click',
			function() { game.showScreen('main-menu'); });
	}
	
	function run() {
		//
		// I know this is empty, there isn't anything to do.
	}
	
	return {
		initialize : initialize,
		run : run
	};
}(BreakoutGame.game));